#!/bin/bash

curl -H 'Content-Type: application/json' -d '{"text": "A Pipeline falhou."}' https://anvisabr.webhook.office.com/webhookb2/478e3a2f-b6ae-4ed1-b575-3b0bff820f52@b67af23f-c3f3-4d35-80c7-b7085f5edd81/IncomingWebhook/78e8edbc5c64492da814caafbee3c301/6952b15b-2fb2-4617-8cdc-bc64a1a5333e
